import com.sun.net.httpserver.HttpContext;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;

import java.net.InetSocketAddress;
import java.util.Map;

//For compiling on the shell on repl: Same on mac
//javac -cp sqlite-jdbc-3.23.1.jar: Main.java
//java -cp sqlite-jdbc-3.23.1.jar: Main

//Use for windows
//javac -cp sqlite-jdbc-3.23.1.jar; Main.java
public class Main {

    public static void main(String[] args) throws IOException {

      // create a port - our Gateway
      int port = 8500;
      
      //create the HTTPserver object
      HttpServer server = HttpServer.create(new InetSocketAddress(port),0);
      
      Database db = new Database("jdbc:sqlite:entertainment.db");
      
      //create a route handler to repond the a request
      // this is our default route
      server.createContext("/", new RouteHandler("Default route handler. No route specified.....") );

     
      /*
        /customers
        route gets all Netflix, Hulu, or Disney+ table
      */
      String sql1 = "select * from netflix;";
      server.createContext("/netflix", new RouteHandler(db,sql1) );

      String sql2 = "Select * from hulu;";
      server.createContext("/hulu", new RouteHandler(db,sql2) );

      String sql3 = "Select * from disneyplus;";
      server.createContext("/disneyplus", new RouteHandler(db,sql3) );

      String sql4 = "Select netflix.title, netflix.year, hulu.title, hulu.year, disneyplus.title, disneyplus.year from netflix inner join hulu, disneyplus ON netflix.year = hulu.year and netflix.year = disneyplus.year;";
      server.createContext("/year", new RouteHandler(db,sql4) );

      String sql5 = "Select netflix.title, netflix.rating, hulu.title, hulu.rating, disneyplus.title, disneyplus.rating from netflix inner join hulu, disneyplus on netflix.rating = hulu.rating and netflix.rating = disneyplus.rating;";
      server.createContext("/rating", new RouteHandler(db,sql5) );

      
      /*
        /playslist/songs
        route gets all customers table
      */
      //String sql2 = "Select playlists.PlayListName, tracks.TrackName,tracks.Composer from playlists inner join playlist_track, tracks on playlists.PlaylistId =playlist_track.PlaylistId and playlist_track.TrackId = tracks.TrackId;";
      //server.createContext("/playslist/songs", new RouteHandler(db,sql2) );
      
      
      //Start the server
      server.start();

      System.out.println("Server is listening on port "+port);
      

      

      
    }    
}


