let data, output, result;
function init(){
  $.ajaxSetup({async: false});
  let link = `https://Website-Project.rafiounjibon.repl.co/netflix`;
  netflix = $.getJSON(link).responseJSON;
  console.log(netflix);
  
  let link2 = `https://Website-Project.rafiounjibon.repl.co/hulu`;
  hulu = $.getJSON(link2).responseJSON;
  console.log(hulu);

  let link3 = `https://Website-Project.rafiounjibon.repl.co/disneyplus`;
  disneyplus = $.getJSON(link3).responseJSON;
  console.log(disneyplus);
  
  output = document.getElementById("output");
  result = document.getElementById("result");


  let build = "";
  let ct = 0;
  for(let i = 0; i < 10; i++){
    let showz = netflix[i];
    build += `<div class="fitted card" id="net">`;
    build += `     <h3>${showz.title}</h3>`;
    build += `     <hr>`;
    build += `     <p>genre: ${showz.genre}</p>`;
    build += `     <p>year: ${showz.year}</p>`;
    build += `     <p>rating: ${showz.rating}</p>`;
    build += `</div>`;
    ct++;
  }
  result.innerHTML = `${ct} Results found.`;
  result.innerHTML = `Shows for Netflix`;
  output.innerHTML = build;

  //let build = "";
  //let ct = 0;
  for(let i = 0; i < 10; i++){
    let showz = hulu[i];
    build += `<div class="fitted card" id="hulu">`;
    build += `     <h3>${showz.title}</h3>`;
    build += `     <hr>`;
    build += `     <p>genre: ${showz.genre}</p>`;
    build += `     <p>year: ${showz.year}</p>`;
    build += `     <p>rating: ${showz.rating}</p>`;
    build += `</div>`;
    ct++;
  }
  result.innerHTML = `${ct} Results found.`;
  result.innerHTML = `Shows for Hulu`;
  output.innerHTML = build;

  
  //let build = "";
  //let ct = 0;
  for(let i = 0; i < 10; i++){
    let showz = disneyplus[i];
    build += `<div class="fitted card" id="disney">`;
    build += `     <h3>${showz.title}</h3>`;
    build += `     <hr>`;
    build += `     <p>genre: ${showz.genre}</p>`;
    build += `     <p>year: ${showz.year}</p>`;
    build += `     <p>rating: ${showz.rating}</p>`;
    build += `</div>`;
    ct++;
  }
  result.innerHTML = `${ct} Results found.`;
  result.innerHTML = `Shows for Disney Plus`;
  output.innerHTML = build;


}
//-----------------------------------------------------
function filterByPlatform(){
  let p = document.getElementById("platform").value;
  let link = `https://Website-Project.rafiounjibon.repl.co/${p}`;
  platform = $.getJSON(link).responseJSON;

  output = document.getElementById("output");
  result = document.getElementById("result");
  let build = "";
  let ct = 0;

  if(p == "netflix"){
    for(let i = 0; i < platform.length; i++){
      let showz = netflix[i];
      build += `<div class="fitted card" id="net">`;
      build += `     <h3>${showz.title}</h3>`;
      build += `     <hr>`;
      build += `     <p>genre: ${showz.genre}</p>`;
      build += `     <p>year: ${showz.year}</p>`;
      build += `     <p>rating: ${showz.rating}</p>`;
      build += `</div>`;
      ct++;
    }
    result.innerHTML = `${ct} Results found.`
    result.innerHTML = `Shows for Netflix`
    output.innerHTML = build;
  }

  if(p == "hulu"){
    for(let i = 0; i < platform.length; i++){
      let showz = hulu[i];
      build += `<div class="fitted card" id="hulu">`;
      build += `     <h3>${showz.title}</h3>`;
      build += `     <hr>`;
      build += `     <p>genre: ${showz.genre}</p>`;
      build += `     <p>year: ${showz.year}</p>`;
      build += `     <p>rating: ${showz.rating}</p>`;
      build += `</div>`;
      ct++;
    }
    result.innerHTML = `${ct} Results found.`
    result.innerHTML = `Shows for Hulu`
    output.innerHTML = build;
  }

  if(p == "disneyplus"){
    for(let i = 0; i < platform.length; i++){
      let showz = disneyplus[i];
      build += `<div class="fitted card" id="disney">`;
      build += `     <h3>${showz.title}</h3>`;
      build += `     <hr>`;
      build += `     <p>genre: ${showz.genre}</p>`;
      build += `     <p>year: ${showz.year}</p>`;
      build += `     <p>rating: ${showz.rating}</p>`;
      build += `</div>`;
      ct++;
    }
    result.innerHTML = `${ct} Results found.`
    result.innerHTML = `Shows for Netflix`
    output.innerHTML = build;
  }

  /*
  for(let i = 0; i < 10; i++){
    let show = platform[i];
    build += `<div class="fitted card">`;
    build += `     <h3>${show.title}</h3>`;
    build += `     <hr>`;
    build += `     <p>genre: ${show.genre}</p>`;
    build += `     <p>rating: ${show.rating}</p>`;
    build += `     <p>year: ${show.year}</p>`;
    build += `</div>`;
    ct++;
  }
  result.innerHTML = `${ct} Results found.`
  output.innerHTML = build;
  */
}
//----------------------------------------------
function filterByShow(){
  let p = document.getElementById("platform").value;
  let link = `https://Website-Project.rafiounjibon.repl.co/${p}`;
  platform = $.getJSON(link).responseJSON;

  let show = document.getElementById("show").value;

  output = document.getElementById("output");
  result = document.getElementById("result");
  let build = "";
  let ct = 0;
  
  for(let i = 0; i < platform.length; i++){
    let s = platform[i];
    if(s.title == show){
      build += `<div class="fitted card">`;
      build += `     <h3> ${s.title}</h3>`;
      build += `     <p>genre: ${s.genre}</p>`;
      build += `     <p>rating: ${s.rating}</p>`;
      build += `     <p>year: ${s.year}</p>`;
      build += `</div>`; 
      ct++;
    }
  }
  result.innerHTML = `${ct} Results found.`;
  output.innerHTML = build;
}

/*
function Hide() {
  var x = document.getElementById("myDIV");
  var y = document.getElementById("platform");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
*/
function filterByYear(){
  let p = document.getElementById("platform").value;
  let link = `https://Website-Project.rafiounjibon.repl.co/${p}`;
  platform = $.getJSON(link).responseJSON;

  let year = document.getElementById("year").value;

  output = document.getElementById("output");
  result = document.getElementById("result");
  let build = "";
  let ct = 0;
  
  for(let i = 0; i < platform.length; i++){
    let s = platform[i];
    if(s.year == year){
      build += `<div class="fitted card">`;
      build += `     <h3> ${s.title}</h3>`;
      build += `     <p>genre: ${s.genre}</p>`;
      build += `     <p>rating: ${s.rating}</p>`;
      build += `     <p>year: ${s.year}</p>`;
      build += `</div>`; 
      ct++;
    }
  }
  result.innerHTML = `${ct} Results found.`;
  output.innerHTML = build;
}

function filterByGenre(){
  let p = document.getElementById("platform").value;
  let link = `https://Website-Project.rafiounjibon.repl.co/${p}`;
  platform = $.getJSON(link).responseJSON;

  let genre = document.getElementById("genre").value;

  output = document.getElementById("output");
  result = document.getElementById("result");
  let build = "";
  let ct = 0;
  
  for(let i = 0; i < platform.length; i++){
    let s = platform[i];
    if(s.genre == genre){
      build += `<div class="fitted card">`;
      build += `     <h3> ${s.title}</h3>`;
      build += `     <p>genre: ${s.genre}</p>`;
      build += `     <p>rating: ${s.rating}</p>`;
      build += `     <p>year: ${s.year}</p>`;
      build += `</div>`; 
      ct++;
    }
  }
  result.innerHTML = `${ct} Results found.`;
  output.innerHTML = build;
}
function filterByRating(){
  let p = document.getElementById("platform").value;
  let link = `https://Website-Project.rafiounjibon.repl.co/${p}`;
  platform = $.getJSON(link).responseJSON;

  let rating = document.getElementById("rating").value;

  output = document.getElementById("output");
  result = document.getElementById("result");
  let build = "";
  let ct = 0;
  
  for(let i = 0; i < platform.length; i++){
    let s = platform[i];
    if(s.rating >= rating){
      build += `<div class="fitted card">`;
      build += `     <h3> ${s.title}</h3>`;
      build += `     <p>genre: ${s.genre}</p>`;
      build += `     <p>rating: ${s.rating}</p>`;
      build += `     <p>year: ${s.year}</p>`;
      build += `</div>`; 
      ct++;
    }
  }
  result.innerHTML = `${ct} Results found.`;
  output.innerHTML = build;
}